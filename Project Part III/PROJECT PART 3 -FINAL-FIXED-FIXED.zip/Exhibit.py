

class exhibit():
    def __init__(self,image_path,exhibit_id):
        self.image_path = image_path
        self.exhibit_id = exhibit_id

